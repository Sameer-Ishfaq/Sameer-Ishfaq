const html = document.documentElement;

document.getElementById("toggleTheme").onclick=() =>{
    html.classList.toggle("dark");
};